// ======================================================================== //
// Copyright 2013 Christoph Husse                                           //
//                                                                          //
// Licensed under the Apache License, Version 2.0 (the "License");          //
// you may not use this file except in compliance with the License.         //
// You may obtain a copy of the License at                                  //
//                                                                          //
//     http://www.apache.org/licenses/LICENSE-2.0                           //
//                                                                          //
// Unless required by applicable law or agreed to in writing, software      //
// distributed under the License is distributed on an "AS IS" BASIS,        //
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
// See the License for the specific language governing permissions and      //
// limitations under the License.                                           //
// ======================================================================== //

using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using System.Collections;


public static class MaterialExtension
{
    public static bool SetCompileFlag(this Material material, string name, bool value)
    {
        if (!value)
            material.shaderKeywords = material.shaderKeywords.Except(new[] { name }).ToArray();
        else
            material.shaderKeywords = material.shaderKeywords.Union(new[] { name }).ToArray();

        return value;
    }

    public static bool GetCompileFlag(this Material material, string name)
    {
        return material.shaderKeywords.Contains(name);
    }

    public static Texture2D GetTexture2D(this Material material, string name)
    {
        if (!material.HasProperty(name))
            return null;

        var tex = material.GetTexture(name);
        if (tex == null)
            return null;

        Texture2D res = tex as Texture2D;
        if (res != null)
            return res;

        Debug.LogWarning("Material texture is not a 2D texture and thus ignored.", material);
        return null;
    }
}

public enum BRDFVisibilityTerm
{
    Default,
    FresnelReflectance,
    FresnelRefractance,
}

public enum KnownBRDFs
{
    Lambert,
    Transmissive,
    Reflective,
    Refractive,
    Microfacet
}

public class BRDFVisibility
{
    public Texture2D alphaMap;
    public Boolean useAlphaMap, isAlphaMapInverted;
    public float percentage = 1;
    public BRDFVisibilityTerm term = BRDFVisibilityTerm.Default;
    public float fresnelRefractiveIndex = 1.5f;

    public override bool Equals(object obj)
    {
        if (obj is BRDFVisibility)
            return Equals(obj as BRDFVisibility);
        else
            return base.Equals(obj);
    }

    public virtual bool Equals(BRDFVisibility other)
    {
        return (alphaMap == other.alphaMap) && (useAlphaMap == other.useAlphaMap) && (isAlphaMapInverted == other.isAlphaMapInverted)
             && (percentage == other.percentage) && (term == other.term) && (fresnelRefractiveIndex == other.fresnelRefractiveIndex);
    }
}

public abstract class BRDFConfig
{
    public BRDFVisibility visibility = new BRDFVisibility();
    public abstract String Title { get; }
    public abstract String Prefix { get; }
    public abstract KnownBRDFs Type { get; }

    public abstract BRDFConfig CopyFrom(Material material);
    public abstract void CopyTo(Material material);

    public override bool Equals(object obj)
    {
        if (obj is BRDFConfig)
            return Equals(obj as BRDFConfig);
        else
            return false;
    }

    private bool Equals(BRDFConfig other)
    {
        return (visibility.Equals(other.visibility)) && (Title == other.Title) && (Prefix == other.Prefix) && (Type == other.Type);
    }

    protected void CopyFrom(Material material, String prefix)
    {
        visibility = new BRDFVisibility();

        if (material.GetCompileFlag(Prefix + "_FRESNEL_REFLECTION"))
        {
            visibility.fresnelRefractiveIndex = material.GetFloat(prefix + "_RefractiveIndex");
            visibility.term = BRDFVisibilityTerm.FresnelReflectance;
        }
        else if (material.GetCompileFlag(Prefix + "_FRESNEL_REFRACTION"))
        {
            visibility.fresnelRefractiveIndex = material.GetFloat(prefix + "_RefractiveIndex");
            visibility.term = BRDFVisibilityTerm.FresnelRefractance;
        }
        else
            visibility.term = BRDFVisibilityTerm.Default;

        visibility.percentage = material.GetFloat(prefix + "_VisibilityPercentage");

        visibility.useAlphaMap = material.GetCompileFlag(prefix + "_USE_ALPHAMAP");
        if (visibility.useAlphaMap)
        {
            visibility.alphaMap = material.GetTexture2D(prefix + "_AlphaMap");
            visibility.isAlphaMapInverted = material.GetCompileFlag(prefix + "_IS_ALPHAMAP_INVERTED");
        }
    }

    protected void CopyTo(Material material, String prefix)
    {
        if (visibility.term == BRDFVisibilityTerm.FresnelReflectance)
        {
            material.SetCompileFlag(prefix + "_FRESNEL_REFLECTION", true);
            material.SetFloat(prefix + "_RefractiveIndex", visibility.fresnelRefractiveIndex);
        }

        if (visibility.term == BRDFVisibilityTerm.FresnelRefractance)
        {
            material.SetCompileFlag(prefix + "_FRESNEL_REFRACTION", true);
            material.SetFloat(prefix + "_RefractiveIndex", visibility.fresnelRefractiveIndex);
        }

        material.SetFloat(prefix + "_VisibilityPercentage", visibility.percentage);

        material.SetTexture(prefix + "_AlphaMap", visibility.alphaMap);
        material.SetCompileFlag(prefix + "_USE_ALPHAMAP", visibility.useAlphaMap);
        material.SetCompileFlag(prefix + "_IS_ALPHAMAP_INVERTED", visibility.isAlphaMapInverted);
    }

    public virtual void Serialize(SerializationContext ctx)
    {
        ctx.writer.Write((Int32)Type);
        ctx.writer.Write((Single)visibility.percentage);
        ctx.writer.Write((Int32)visibility.term);
        ctx.writer.Write((Single)visibility.fresnelRefractiveIndex);

        ctx.writer.Write((Boolean)visibility.useAlphaMap);
        if (visibility.useAlphaMap)
        {
            MaterialConfig.WriteTexture(ctx, visibility.alphaMap);
            ctx.writer.Write((Boolean)visibility.isAlphaMapInverted);
        }
    }

    public static BRDFConfig DeserializeStatic(SerializationContext ctx)
    {
        BRDFConfig res;

        switch ((KnownBRDFs)ctx.reader.ReadInt32())
        {
            case KnownBRDFs.Lambert: res = new LambertBRDF();
                break;
            case KnownBRDFs.Transmissive: res = new TransmissiveBRDF();
                break;
            case KnownBRDFs.Reflective: res = new ReflectiveBRDF();
                break;
            case KnownBRDFs.Refractive: res = new RefractiveBRDF();
                break;
            case KnownBRDFs.Microfacet: res = new MicrofacetBRDF();
                break;

            default:
                throw new ArgumentException("Unknown BRDF!");
        }

        res.Deserialize(ctx);
        return res;
    }

    public virtual void Deserialize(SerializationContext ctx)
    {
        visibility.percentage = ctx.reader.ReadSingle();
        visibility.term = (BRDFVisibilityTerm)ctx.reader.ReadInt32();
        visibility.fresnelRefractiveIndex = ctx.reader.ReadSingle();

        if (visibility.useAlphaMap = ctx.reader.ReadBoolean())
        {
            visibility.alphaMap = MaterialConfig.ReadTexture(ctx);
            visibility.isAlphaMapInverted = ctx.reader.ReadBoolean();
        }
    }

    public virtual void EnumTextures(HashSet<Texture2D> textures)
    {
        if (visibility.useAlphaMap && (visibility.alphaMap != null) && !textures.Contains(visibility.alphaMap))
            textures.Add(visibility.alphaMap);
    }
}

public sealed class LambertBRDF : BRDFConfig
{
    public Texture2D colorMap;
    public Color color;
    public bool isEmissive = false;
    public bool emitDirectional = false;
    public bool emitsPhotons = false;
    public float emissiveIntensity = 1;
    public float photonIntensity = 5;
    public float photonMultiplier = 1;

    public override String Title { get { return "Lambert BRDF"; } }
    public override KnownBRDFs Type { get { return KnownBRDFs.Lambert; } }
    public override String Prefix { get { return "LAMBERT"; } }

    public override bool Equals(object obj)
    {
        if (obj is LambertBRDF)
            return Equals(obj as LambertBRDF);
        else
            return false;
    }

    private bool Equals(LambertBRDF other)
    {
        return base.Equals(other) && (colorMap == other.colorMap) && (color == other.color) && (isEmissive == other.isEmissive)
             && (emitDirectional == other.emitDirectional) && (emitsPhotons == other.emitsPhotons)
             && (emissiveIntensity == other.emissiveIntensity) && (photonIntensity == other.photonIntensity)
             && (photonMultiplier == other.photonMultiplier);
    }

    public override BRDFConfig CopyFrom(Material material)
    {
        base.CopyFrom(material, "LAMBERT");

        color = material.GetColor("LAMBERT_Color");
        colorMap = material.GetTexture2D("LAMBERT_ColorMap");

        isEmissive = material.GetCompileFlag("LAMBERT_IS_EMISSIVE");
        emissiveIntensity = material.GetFloat("LAMBERT_EmissiveIntensity");

        emitsPhotons = material.GetCompileFlag("LAMBERT_EMITS_PHOTONS");
        emitDirectional = material.GetCompileFlag("LAMBERT_EMIT_DIRECTIONAL");
        photonIntensity = material.GetFloat("LAMBERT_PhotonIntensity");
        photonMultiplier = material.GetFloat("LAMBERT_PhotonMultiplier");

        return this;
    }

    public override void CopyTo(Material material)
    {
        base.CopyTo(material, "LAMBERT");

        material.SetCompileFlag("LAMBERT_ENABLED", true);
        material.SetColor("LAMBERT_Color", color);
        material.SetTexture("LAMBERT_ColorMap", colorMap);

        material.SetCompileFlag("LAMBERT_IS_EMISSIVE", isEmissive);
        material.SetFloat("LAMBERT_EmissiveIntensity", emissiveIntensity);

        material.SetCompileFlag("LAMBERT_EMITS_PHOTONS", emitsPhotons);
        material.SetCompileFlag("LAMBERT_EMIT_DIRECTIONAL", emitDirectional);
        material.SetFloat("LAMBERT_PhotonIntensity", photonIntensity);
        material.SetFloat("LAMBERT_PhotonMultiplier", photonMultiplier);
    }

    public override void EnumTextures(HashSet<Texture2D> textures)
    {
        base.EnumTextures(textures);

        if ((colorMap != null) && !textures.Contains(colorMap))
            textures.Add(colorMap);
    }

    public override void Serialize(SerializationContext ctx)
    {
        base.Serialize(ctx);

        ctx.WriteColor(color);
        MaterialConfig.WriteTexture(ctx, colorMap);

        ctx.writer.Write((Boolean)isEmissive);
        ctx.writer.Write((Single)emissiveIntensity);

        ctx.writer.Write((Boolean)emitsPhotons);
        ctx.writer.Write((Boolean)emitDirectional);
        ctx.writer.Write((Single)photonIntensity);
        ctx.writer.Write((Single)photonMultiplier);
    }

    public override void Deserialize(SerializationContext ctx)
    {
        base.Deserialize(ctx);

        color = ctx.ReadColor();
        colorMap = MaterialConfig.ReadTexture(ctx);

        isEmissive = ctx.reader.ReadBoolean();
        emissiveIntensity = ctx.reader.ReadSingle();

        emitsPhotons = ctx.reader.ReadBoolean();
        emitDirectional = ctx.reader.ReadBoolean();
        photonIntensity = ctx.reader.ReadSingle();
        photonMultiplier = ctx.reader.ReadSingle();
    }
}

public sealed class TransmissiveBRDF : BRDFConfig
{

    public override String Title { get { return "Transmissive BRDF"; } }
    public override KnownBRDFs Type { get { return KnownBRDFs.Transmissive; } }
    public override String Prefix { get { return "TRANSMISSIVE"; } }

    public override BRDFConfig CopyFrom(Material material)
    {
        base.CopyFrom(material, "TRANSMISSIVE");


        return this;
    }

    public override void CopyTo(Material material)
    {
        base.CopyTo(material, "TRANSMISSIVE");

        material.SetCompileFlag("TRANSMISSIVE_ENABLED", true);
    }

}

public sealed class ReflectiveBRDF : BRDFConfig
{
    public override String Title { get { return "Reflective BRDF"; } }
    public override KnownBRDFs Type { get { return KnownBRDFs.Reflective; } }
    public override String Prefix { get { return "REFLECTIVE"; } }

    public override BRDFConfig CopyFrom(Material material)
    {
        base.CopyFrom(material, "REFLECTIVE");

        return this;
    }

    public override void CopyTo(Material material)
    {
        base.CopyTo(material, "REFLECTIVE");

        material.SetCompileFlag("REFLECTIVE_ENABLED", true);
    }


    public override void Serialize(SerializationContext ctx)
    {
        base.Serialize(ctx);
        ctx.writer.Write((Single)visibility.fresnelRefractiveIndex);
    }

    public override void Deserialize(SerializationContext ctx)
    {
        base.Deserialize(ctx);
        ctx.reader.ReadSingle();
    }
}

public sealed class RefractiveBRDF : BRDFConfig
{
    public override String Title { get { return "Refractive BRDF"; } }
    public override KnownBRDFs Type { get { return KnownBRDFs.Refractive; } }
    public override String Prefix { get { return "REFRACTIVE"; } }

    public override BRDFConfig CopyFrom(Material material)
    {
        base.CopyFrom(material, "REFRACTIVE");

        return this;
    }

    public override void CopyTo(Material material)
    {
        base.CopyTo(material, "REFRACTIVE");

        material.SetCompileFlag("REFRACTIVE_ENABLED", true);
    }


    public override void Serialize(SerializationContext ctx)
    {
        base.Serialize(ctx);
        ctx.writer.Write((Single)visibility.fresnelRefractiveIndex);
    }

    public override void Deserialize(SerializationContext ctx)
    {
        base.Deserialize(ctx);
        ctx.reader.ReadSingle();
    }
}

public sealed class MicrofacetBRDF : BRDFConfig
{
    public override String Title { get { return "Microfacet BRDF"; } }
    public override KnownBRDFs Type { get { return KnownBRDFs.Microfacet; } }
    public override String Prefix { get { return "MICROFACET"; } }

    public override BRDFConfig CopyFrom(Material material)
    {
        base.CopyFrom(material, "MICROFACET");

        return this;
    }

    public override void CopyTo(Material material)
    {
        base.CopyTo(material, "MICROFACET");

        material.SetCompileFlag("MICROFACET_ENABLED", true);
    }
}

public class MaterialConfig
{
    private Shader diffuseShader, specularShader, bumpedDiffuseShader, bumpedSpecularShader, transDiffuseShader,
        transSpecularShader, transBumpedDiffuseShader, transBumpedSpecularShader, rayTracingShader;
    private const int TEXTURE_UID = 112390478;
    public readonly List<BRDFConfig> brdfs = new List<BRDFConfig>();
    public string name = "";
    public Texture2D bumpMap;
    
    public override int GetHashCode()
    {
        return 0;
    }

    public override bool Equals(object obj)
    {
        if (obj is MaterialConfig)
            return Equals(obj as MaterialConfig);
        else
            return false;
    }

    public bool Equals(MaterialConfig other)
    {
        if(brdfs.Count != other.brdfs.Count)
            return false;

        for (int i = 0; i < brdfs.Count; i++ )
        {
            if (!brdfs[i].Equals(other.brdfs[i]))
                return false;
        }

        return true;
    }

    public static void WriteTexture(SerializationContext ctx, Texture2D texture)
    {
        if (texture != null)
        {
            var path = AssetDatabase.GetAssetPath(texture);
            var asset = AssetImporter.GetAtPath(path);

            if (asset is TextureImporter)
            {
                var ti = (TextureImporter) asset;

                if (!ti.isReadable || (ti.npotScale != TextureImporterNPOTScale.None) || (ti.maxTextureSize != 2048))
                {
                    ti.textureFormat = TextureImporterFormat.AutomaticTruecolor;
                    ti.npotScale = TextureImporterNPOTScale.None;
                    ti.maxTextureSize = 2048;
                    ti.isReadable = true;
                    ti.mipmapEnabled = true;
                    AssetDatabase.ImportAsset(path);
                }
            }
        }

        ctx.writer.Write((Int32)TEXTURE_UID);

        ctx.writer.Write((Boolean)(texture != null));
        if (texture == null)
            return;

        long textureHash = 0;
        if (!ctx.HasTexture(texture, out textureHash))
        {
            int channelCount;
            switch (texture.format)
            {
                case TextureFormat.Alpha8:
                    channelCount = 1;
                    break;

                case TextureFormat.ARGB32:
                case TextureFormat.BGRA32:
                case TextureFormat.DXT1:
                case TextureFormat.DXT5:
                case TextureFormat.RGBA4444:
                case TextureFormat.RGBA32:
                case TextureFormat.ARGB4444:
                    channelCount = 4;
                    break;

                case TextureFormat.RGB565:
                case TextureFormat.RGB24:
                    channelCount = 3;
                    break;

                default:
                    throw new ArgumentException("Texture \"" + texture.name + "\" has an unsupported format " + texture.format + "!");
            }

            var pixels = texture.GetPixels32();
            byte[] pixelBytes = new byte[pixels.Length * channelCount];

            for (int i = 0, j = 0; i < pixels.Length; i++)
            {
                if (channelCount == 4)
                {
                    pixelBytes[j++] = pixels[i].r;
                    pixelBytes[j++] = pixels[i].g;
                    pixelBytes[j++] = pixels[i].b;
                    pixelBytes[j++] = pixels[i].a;
                }
                else if (channelCount == 3)
                {
                    pixelBytes[j++] = pixels[i].r;
                    pixelBytes[j++] = pixels[i].g;
                    pixelBytes[j++] = pixels[i].b;
                }
                else
                {
                    pixelBytes[j++] = pixels[i].a;
                }
            }

            byte[] hashCode = System.Security.Cryptography.MD5.Create().ComputeHash(pixelBytes);

            for (int i = 0; i < hashCode.Length; i++)
            {
                textureHash ^= ((long) hashCode[i]) << ((i%8)*8);
            }

            ctx.writer.Write((long) textureHash);
            if (!ctx.AddTexture(textureHash, texture))
                return;

            ctx.WriteString(texture.name);
            ctx.writer.Write((Int32)channelCount);
            ctx.writer.Write((Int32)texture.width);
            ctx.writer.Write((Int32)texture.height);
            ctx.writer.Write((Int32)pixelBytes.Length);
            ctx.writer.Write(pixelBytes, 0, pixelBytes.Length);
        }
        else
        {
            ctx.writer.Write((long)textureHash);
        }
    }

    public static Texture2D ReadTexture(SerializationContext ctx)
    {
        if (ctx.reader.ReadInt32() != TEXTURE_UID)
            throw new ArgumentException("Invalid magic number.");

        if (!ctx.reader.ReadBoolean())
            return null;

        long textureHash = ctx.reader.ReadInt64();
        Texture2D tex;

        if ((tex = ctx.GetTexture(textureHash)) != null)
            return tex;

        var name = ctx.ReadString();
        int channelCount = ctx.reader.ReadInt32();
        int width = ctx.reader.ReadInt32();
        int height = ctx.reader.ReadInt32();
        int length = ctx.reader.ReadInt32();
        byte[] pixelBytes = ctx.reader.ReadBytes(length);
        Color32[] pixels = new Color32[length / channelCount];

        for (int i = 0, j = 0; i < pixels.Length; i++)
        {
            pixels[i] = new Color32(0,0,0,255);

            if (channelCount == 4)
            {
                pixels[i].r = pixelBytes[j++];
                pixels[i].g = pixelBytes[j++];
                pixels[i].b = pixelBytes[j++];
                pixels[i].a = pixelBytes[j++];
            }
            else if (channelCount == 3)
            {
                pixels[i].r = pixelBytes[j++];
                pixels[i].g = pixelBytes[j++];
                pixels[i].b = pixelBytes[j++];
            }
            else
            {
                pixels[i].a = pixelBytes[j++];
            }
        } 

        var fmt = TextureFormat.RGBA32;
        if(channelCount == 3) fmt = TextureFormat.RGB24;
        if(channelCount == 1) fmt = TextureFormat.Alpha8;

        tex = new Texture2D(width, height, fmt, false);
        tex.SetPixels32(pixels);
        tex.Apply(false);
        tex.name = name;
        ctx.AddTexture(textureHash, tex);
        return tex;
    }

    private void initShaders()
    {
        if (diffuseShader != null)
            return;

        diffuseShader = Shader.Find("Diffuse");
        specularShader = Shader.Find("Specular");
        bumpedDiffuseShader = Shader.Find("Bumped Diffuse");
        bumpedSpecularShader = Shader.Find("Bumped Specular");
        transDiffuseShader = Shader.Find("Transparent/Diffuse");
        transSpecularShader = Shader.Find("Transparent/Specular");
        transBumpedDiffuseShader = Shader.Find("Transparent/Bumped Diffuse");
        transBumpedSpecularShader = Shader.Find("Transparent/Bumped Diffuse");
        rayTracingShader = Shader.Find("RayTracingShader");
    }

    public void CopyTo(Material mat)
    {
        initShaders();

        mat.name = name;
        mat.shader = rayTracingShader;
        mat.shaderKeywords = new string[0];

        mat.SetTexture("BumpMap", bumpMap);

        foreach (var brdf in brdfs) brdf.CopyTo(mat);
    }

    public void CopyFrom(Material material)
    {
        initShaders();

        name = material.name;
        brdfs.Clear();

        if (material.shader == transDiffuseShader)
        {
            brdfs.Add(
                new LambertBRDF()
                {
                    color = material.GetColor("_Color"),
                    colorMap = material.GetTexture2D("_MainTex")
                });

            brdfs.Add(
                new TransmissiveBRDF()
                {
                });
        }
        else if (material.shader == diffuseShader)
        {
            brdfs.Add(
                new LambertBRDF()
                {
                    color = material.GetColor("_Color"),
                    colorMap = material.GetTexture2D("_MainTex")
                });
        }
        else if (material.shader == rayTracingShader)
        {
            bumpMap = material.GetTexture2D("BumpMap");

            if (material.GetCompileFlag("LAMBERT_ENABLED")) brdfs.Add(new LambertBRDF().CopyFrom(material));
            if (material.GetCompileFlag("TRANSMISSIVE_ENABLED")) brdfs.Add(new TransmissiveBRDF().CopyFrom(material));
            if (material.GetCompileFlag("REFLECTIVE_ENABLED")) brdfs.Add(new ReflectiveBRDF().CopyFrom(material));
            if (material.GetCompileFlag("REFRACTIVE_ENABLED")) brdfs.Add(new RefractiveBRDF().CopyFrom(material));
            if (material.GetCompileFlag("MICROFACET_ENABLED")) brdfs.Add(new MicrofacetBRDF().CopyFrom(material));

            //if((brdfs.Count(e => e.visibility.useAlphaMap && (e.visibility.alphaMap != null)) == 1) && !brdfs.Any(e => e is TransmissiveBRDF))
            //{
            //    var brdf = brdfs.First(e => e.visibility.useAlphaMap);
            //    if(!brdf.visibility.isAlphaMapInverted && brdf.visibility.alphaMap)
            //    {
            //        Debug.Log("Adding automatic alpha-blend BRDF for \"" + material + "\".");

            //        // add transmissive BRDF for alpha blending
            //        var blend = new TransmissiveBRDF();

            //        blend.visibility.useAlphaMap = true;
            //        blend.visibility.isAlphaMapInverted = true;
            //        blend.visibility.alphaMap = brdf.visibility.alphaMap;
            //        blend.visibility.percentage = brdf.visibility.percentage;
            //        blend.visibility.term = brdf.visibility.term;
            //        blend.visibility.fresnelRefractiveIndex = brdf.visibility.fresnelRefractiveIndex;

            //        brdfs.Add(blend);
            //    }
            //}
        }
        else
        {
            Debug.LogWarning("Material is using an unrecognized shader and thus will be threaded as default diffuse.", material);
        }
    }

    public IEnumerable<Texture2D> EnumTextures()
    {
        HashSet<Texture2D> textures = new HashSet<Texture2D>();

        if (bumpMap && !textures.Contains(bumpMap))
            textures.Add(bumpMap);

        foreach (var brdf in brdfs)
        {
            brdf.EnumTextures(textures);
        }
        return textures;
    }

    public static bool HasBRDFs(Material material)
    {
        var cfg = new MaterialConfig();
        cfg.CopyFrom(material);
        return cfg.brdfs.Any();
    }

    public void Serialize(SerializationContext ctx)
    {
        ctx.WriteString(name);
        WriteTexture(ctx, bumpMap);
        ctx.writer.Write((Int32)brdfs.Count);
        foreach (var brdf in brdfs)
        {
            brdf.Serialize(ctx);
        }
    }

    public void Deserialize(SerializationContext ctx)
    {
        name = ctx.ReadString();
        bumpMap = ReadTexture(ctx);
        int brdfCount = ctx.reader.ReadInt32();
        brdfs.Clear();

        for (int i = 0; i < brdfCount; i++)
        {
            brdfs.Add(BRDFConfig.DeserializeStatic(ctx));
        }
    }
}