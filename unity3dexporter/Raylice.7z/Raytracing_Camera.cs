// ======================================================================== //
// Copyright 2013 Christoph Husse                                           //
//                                                                          //
// Licensed under the Apache License, Version 2.0 (the "License");          //
// you may not use this file except in compliance with the License.         //
// You may obtain a copy of the License at                                  //
//                                                                          //
//     http://www.apache.org/licenses/LICENSE-2.0                           //
//                                                                          //
// Unless required by applicable law or agreed to in writing, software      //
// distributed under the License is distributed on an "AS IS" BASIS,        //
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
// See the License for the specific language governing permissions and      //
// limitations under the License.                                           //
// ======================================================================== //

using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Camera))]
public class Raytracing_Camera : Raytracing_Serializable
{
    public override void Serialize(SerializationContext ctx, GameObject root)
    {
        ctx.writer.Write((Int32)CAMERA_UID);

        camera.ResetAspect();

        ctx.WriteString(camera.name);
        Debug.Log("Camera \"" + camera.name + "\" aspect: " + camera.aspect);
        ctx.writer.Write((Single)camera.aspect);
        ctx.WriteMatrix(camera.worldToCameraMatrix);
        ctx.WriteMatrix( camera.projectionMatrix);
        

        // this is ignored by the raytracer and only used to properly reload the scene with Unity3D
        ctx.writer.Write((Single)camera.near);
        ctx.writer.Write((Single)camera.far);
        ctx.writer.Write((Single)camera.depth);
        ctx.writer.Write((Single)camera.fov);
        ctx.writer.Write((Boolean)camera.isOrthoGraphic);
        ctx.writer.Write((Single)camera.orthographicSize);
        ctx.WriteVector3(transform.position);
        ctx.WriteQuaternion(transform.rotation);
        ctx.writer.Write((Single)camera.pixelRect.left);
        ctx.writer.Write((Single)camera.pixelRect.top);
        ctx.writer.Write((Single)camera.pixelRect.width);
        ctx.writer.Write((Single)camera.pixelRect.height);
    }

    public override void Deserialize(SerializationContext ctx)
    {
        if(!camera)
            gameObject.AddComponent<Camera>();

        camera.name = ctx.ReadString();
        camera.aspect = ctx.reader.ReadSingle();
        ctx.ReadMatrix();
        ctx.ReadMatrix();

        // this is ignored by the raytracer and only used to properly reload the scene with Unity3D
        camera.near = ctx.reader.ReadSingle();
        camera.far = ctx.reader.ReadSingle();
        camera.depth = ctx.reader.ReadSingle();
        camera.fov = ctx.reader.ReadSingle();
        camera.isOrthoGraphic = ctx.reader.ReadBoolean();
        camera.orthographicSize = ctx.reader.ReadSingle();
        transform.position = ctx.ReadVector3();
        transform.rotation = ctx.ReadQuaternion();
        float left = ctx.reader.ReadSingle();
        float top = ctx.reader.ReadSingle();
        float width = ctx.reader.ReadSingle();
        float height = ctx.reader.ReadSingle();
        camera.pixelRect = new Rect(left, top, width, height);
    }
}
