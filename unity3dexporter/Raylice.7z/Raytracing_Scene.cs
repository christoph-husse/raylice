// ======================================================================== //
// Copyright 2013 Christoph Husse                                           //
//                                                                          //
// Licensed under the Apache License, Version 2.0 (the "License");          //
// you may not use this file except in compliance with the License.         //
// You may obtain a copy of the License at                                  //
//                                                                          //
//     http://www.apache.org/licenses/LICENSE-2.0                           //
//                                                                          //
// Unless required by applicable law or agreed to in writing, software      //
// distributed under the License is distributed on an "AS IS" BASIS,        //
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
// See the License for the specific language governing permissions and      //
// limitations under the License.                                           //
// ======================================================================== //

using System;
using System.Collections.Generic;
using System.IO;
using System.Security.AccessControl;
using System.Text;
using System.Threading;
using UnityEngine;
using System.Linq;
using System.Collections;

public class Raytracing_Scene : Raytracing_Serializable
{
    public override void Serialize(SerializationContext ctx, GameObject root)
    {
        ctx.writer.Write((Int32)SCENE_UID);

        SerializeGeometry(ctx, root);
    }

    public override void Deserialize(SerializationContext ctx)
    {
        DeserializeGeometry(ctx, gameObject);
    }

    private void DeserializeGeometry(SerializationContext ctx, GameObject current)
    {
        if(ctx.reader.ReadInt32() != GAME_OBJECT_UID)
            throw new ArgumentException("Unexpected magic number.");

        current.name = ctx.ReadString();
        int uid;

        while((uid = ctx.reader.ReadInt32()) == MESH_UID)
        {
            var meshes = new List<Mesh>();
            DeserializeTriangles(ctx, meshes);
            var material = DeserializeMaterial(ctx);

            // create game object for each mesh and apply material
            foreach (var mesh in meshes)
            {
                GameObject meshObj = new GameObject();
                meshObj.name = mesh.name;
                meshObj.transform.parent = current.transform;
                meshObj.AddComponent<MeshFilter>().sharedMesh = mesh;
                meshObj.AddComponent<MeshRenderer>();
                meshObj.renderer.sharedMaterial = material;
            }
        }

        if (uid != GAME_OBJECT_CHILDS_UID)
            throw new ArgumentException("Unexpected magic number.");

        // deserialize children
        int childCount = ctx.reader.ReadInt32();
        for (int i = 0; i < childCount; i++)
        {
            GameObject child = new GameObject();

            DeserializeGeometry(ctx, child);
            child.transform.parent = current.transform;
        }
    }

    private Material DeserializeMaterial(SerializationContext ctx)
    {
        if (ctx.reader.ReadInt32() != MATERIAL_UID)
            throw new ArgumentException("This is not the begin of a material.");

        var cfg = new MaterialConfig();
        cfg.Deserialize(ctx);
        return ctx.InstanciateMaterial(cfg);
    }

    private void SerializeMaterial(SerializationContext ctx, Material material)
    {
        ctx.writer.Write((Int32)MATERIAL_UID);
        var mat = new MaterialConfig();
        mat.CopyFrom(material);

        mat.Serialize(ctx);
    }

    private bool DeserializeTriangles(SerializationContext ctx, List<Mesh> meshes)
    {
        var name = ctx.ReadString();
        int triangleCount = ctx.reader.ReadInt32();
        bool hasUVs = ctx.reader.ReadBoolean();
        var triangles = new List<int>();
        var vertices = new List<Vector3>();
        var normals = new List<Vector3>();
        var uvs = hasUVs ? new List<Vector2>() : null;

        Mesh mesh = new Mesh();
        mesh.name = name;

        for (int i = 0, j = 0; i < triangleCount * 3; i++)
        {
            triangles.Add(j++);

            float x = ctx.reader.ReadSingle();
            float y = ctx.reader.ReadSingle();
            float z = ctx.reader.ReadSingle();
            vertices.Add(new Vector3(x, y, z));

            x = ctx.reader.ReadSingle();
            y = ctx.reader.ReadSingle();
            z = ctx.reader.ReadSingle();
            normals.Add(new Vector3(x, y, z));

            if (uvs != null)
            {
                x = ctx.reader.ReadSingle();
                y = ctx.reader.ReadSingle();
                uvs.Add(new Vector2(x, y));
            }

            if ((triangles.Count >= 63000) || (i == triangleCount * 3 - 1))
            {
                mesh.vertices = vertices.ToArray();
                mesh.normals = normals.ToArray();
                if (hasUVs) mesh.uv = uvs.ToArray();
                mesh.triangles = triangles.ToArray();

                meshes.Add(mesh);
                mesh = new Mesh();
                j = 0;

                vertices.Clear();
                normals.Clear();
                triangles.Clear();
                if (hasUVs) uvs.Clear();
            }
        }

        return true;
    }

    private void SerializeGeometry(SerializationContext ctx, GameObject current)
    {
        ctx.writer.Write((Int32)GAME_OBJECT_UID);
        ctx.WriteString(current.name);

        // serialize mesh of current object
        if (current.gameObject.activeInHierarchy)
        {
            var renderer = current.GetComponent<MeshRenderer>();
            var skinRenderer = current.GetComponent<SkinnedMeshRenderer>();

            if (skinRenderer != null)
            {
                Mesh mesh = new Mesh();
                skinRenderer.BakeMesh(mesh);
                SerializeMesh(ctx, current, mesh, skinRenderer.sharedMaterials);
            }
            else if (renderer != null)
            {
                SerializeMesh(ctx, current, renderer.GetComponent<MeshFilter>().sharedMesh, renderer.sharedMaterials);
            }
        }

        ctx.writer.Write((Int32)GAME_OBJECT_CHILDS_UID);
        ctx.writer.Write((Int32)current.transform.childCount);

        // serialize childs
        for (int i = 0; i < current.transform.childCount; i++)
        {
            SerializeGeometry(ctx, current.transform.GetChild(i).gameObject);
        }
    }

    private void SerializeMesh(SerializationContext ctx, GameObject gameObj, Mesh mesh, Material[] materials)
    {
        if (mesh.subMeshCount > 0)
        {
            for (int i = 0; i < mesh.subMeshCount; i++)
            {
                if (mesh.GetTopology(i) != MeshTopology.Triangles)
                {
                    Debug.LogWarning("Mesh is not made of triangles and thus ignored!");
                    continue;
                }

                if (MaterialConfig.HasBRDFs(materials[i]))
                {
                    SerializeTriangles(ctx, gameObj, mesh, mesh.GetTriangles(i));
                    SerializeMaterial(ctx, materials[i]);
                }
            }
        }
        else
        {
            if (MaterialConfig.HasBRDFs(materials[0]))
            {
                SerializeTriangles(ctx, gameObj, mesh, mesh.triangles);
                SerializeMaterial(ctx, materials[0]);
            }
        }
    }

    private void SerializeTriangles(SerializationContext ctx, GameObject gameObj, Mesh mesh, int[] triangles)
    {
        ctx.writer.Write((Int32)MESH_UID);

        ctx.WriteString(gameObj.name);
        ctx.writer.Write((Int32)triangles.Length / 3);
        ctx.writer.Write((Boolean)(mesh.uv != null));

        var vertices = mesh.vertices;
        var normals = mesh.normals;
        var uvs = mesh.uv;

        for (int i = 0; i < triangles.Length; i++)
        {
            int iVertex = triangles[i];
            var v = gameObj.transform.TransformPoint(vertices[iVertex]);

            ctx.writer.Write((Single)v.x);
            ctx.writer.Write((Single)v.y);
            ctx.writer.Write((Single)v.z);

            v = gameObj.transform.TransformDirection(normals[iVertex]);

            ctx.writer.Write((Single)v.x);
            ctx.writer.Write((Single)v.y);
            ctx.writer.Write((Single)v.z);

            if (uvs != null)
            {
                var uv = uvs[iVertex];
                ctx.writer.Write((Single)uv.x);
                ctx.writer.Write((Single)uv.y);
            }
        }
    }
}


public class SerializationContext
{
    public readonly BinaryWriter writer;
    public readonly BinaryReader reader;
    private readonly Dictionary<long, Texture2D> textures = new Dictionary<long, Texture2D>();
    private readonly Dictionary<MaterialConfig, Material> materialInstances = new Dictionary<MaterialConfig, Material>(); 

    public Material InstanciateMaterial(MaterialConfig cfg)
    {
        Material material;
        if (!materialInstances.TryGetValue(cfg, out material))
        {
            // this is a new material...
            material = new Material(Shader.Find("Diffuse"));
            cfg.CopyTo(material);
            materialInstances.Add(cfg, material);
        }

        return material;
    }

    public SerializationContext(FileStream stream, FileAccess access)
    {
        if (access == FileAccess.Write)
        {
            stream.SetLength(0);
            writer = new BinaryWriter(stream, Encoding.UTF8);
        }
        else
        {
            stream.Position = 0;
            reader = new BinaryReader(stream, Encoding.UTF8);
        }
    }

    public bool HasTexture(Texture2D tex, out long hashCode)
    {
        hashCode = 0;

        foreach(var e in textures)
        {
            if(e.Value == tex)
            {
                hashCode = e.Key;
                return true;
            }
        }

        return false;
    }

    public bool AddTexture(long hashCode, Texture2D tex)
    {
        if (textures.ContainsKey(hashCode))
            return false;

        textures.Add(hashCode, tex);
        return true;
    }

    public Texture2D GetTexture(long hashCode)
    {
        Texture2D res;
        textures.TryGetValue(hashCode, out res);
        return res;
    }

    public void WriteColor(Color color)
    {
        writer.Write((Single)color.a);
        writer.Write((Single)color.r);
        writer.Write((Single)color.g);
        writer.Write((Single)color.b);
    }

    public Color ReadColor()
    {
        float a = reader.ReadSingle();
        float r = reader.ReadSingle();
        float g = reader.ReadSingle();
        float b = reader.ReadSingle();
        return new Color(r, g, b, a);
    }

    public void WriteVector3(Vector3 vector)
    {
        writer.Write((Single)vector.x);
        writer.Write((Single)vector.y);
        writer.Write((Single)vector.z);
    }

    public Vector3 ReadVector3()
    {
        float x = reader.ReadSingle();
        float y = reader.ReadSingle();
        float z = reader.ReadSingle();
        return new Vector3(x, y, z);
    }

    public void WriteQuaternion(Quaternion quat)
    {
        writer.Write((Single)quat.x);
        writer.Write((Single)quat.y);
        writer.Write((Single)quat.z);
        writer.Write((Single)quat.w);
    }

    public Quaternion ReadQuaternion()
    {
        float x = reader.ReadSingle();
        float y = reader.ReadSingle();
        float z = reader.ReadSingle();
        float w = reader.ReadSingle();
        return new Quaternion(x, y, z, w);
    }

    public void WriteString(String str)
    {
        var bytes = Encoding.UTF8.GetBytes(str);
        writer.Write((Int32)bytes.Length);
        writer.Write(bytes, 0, bytes.Length);
    }

    public String ReadString()
    {
        int byteCount = reader.ReadInt32();
        return Encoding.UTF8.GetString(reader.ReadBytes(byteCount));
    }

    public void WriteMatrix(Matrix4x4 mat)
    {
        for (int col = 0; col < 4; col++)
        {
            for (int row = 0; row < 4; row++)
            {
                writer.Write((Single)mat[row, col]);
            }
        }
    }

    public Matrix4x4 ReadMatrix()
    {
        Matrix4x4 mat = new Matrix4x4();

        for (int col = 0; col < 4; col++)
        {
            for (int row = 0; row < 4; row++)
            {
                mat[row, col] = reader.ReadSingle();
            }
        }

        return mat;
    }
}