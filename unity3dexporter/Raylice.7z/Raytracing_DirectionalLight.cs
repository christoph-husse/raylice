// ======================================================================== //
// Copyright 2013 Christoph Husse                                           //
//                                                                          //
// Licensed under the Apache License, Version 2.0 (the "License");          //
// you may not use this file except in compliance with the License.         //
// You may obtain a copy of the License at                                  //
//                                                                          //
//     http://www.apache.org/licenses/LICENSE-2.0                           //
//                                                                          //
// Unless required by applicable law or agreed to in writing, software      //
// distributed under the License is distributed on an "AS IS" BASIS,        //
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
// See the License for the specific language governing permissions and      //
// limitations under the License.                                           //
// ======================================================================== //

using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using UnityEngine;
using System.Collections;

public class Raytracing_DirectionalLight : Raytracing_Serializable
{
    //public Light unityLight;
    //public GameObject unityLightMesh;
    //public GameObject unitySkybox;

    private bool SerializeMeshLink(SerializationContext ctx, GameObject root)
    {
        //var renderers = root.GetComponentsInChildren<MeshRenderer>();

        //if (renderers.Length == 0)
        //    return false;

        //ctx.writer.Write((Int32)ctx.GetObjectId(root));
        return true;
    }

    public override void Serialize(SerializationContext ctx, GameObject root)
    {
        //ctx.writer.Write(DIRECTIONAL_LIGHT_UID);

        //// check & serialize light
        //if((unityLight == null) || (light.type != LightType.Directional))
        //    throw new ArgumentException("A raytraced directional needs to be linked to a Unity DirectionalLight!");

        //SerializeMeshLink(ctx, unityLight.gameObject);
        //ctx.WriteVector3(unityLight.transform.TransformDirection(new Vector3(0,0,1)));

        //if (!SerializeMeshLink(ctx, unityLightMesh ?? gameObject))
        //    throw new ArgumentException("A raytraced directional needs at least one mesh from which to cast photons!");

        //// check skybox
        //if(unitySkybox != null)
        //{
        //    ctx.writer.Write(true);
        //    SerializeMeshLink(ctx, unitySkybox);
        //}
        //else
        //    ctx.writer.Write(false);
    }

    public override void Deserialize(SerializationContext ctx)
    {
        //unityLight = DeserializeMeshLink(ctx);
        //unityLight.
    }
}
