﻿// ======================================================================== //
// Copyright 2013 Christoph Husse                                           //
//                                                                          //
// Licensed under the Apache License, Version 2.0 (the "License");          //
// you may not use this file except in compliance with the License.         //
// You may obtain a copy of the License at                                  //
//                                                                          //
//     http://www.apache.org/licenses/LICENSE-2.0                           //
//                                                                          //
// Unless required by applicable law or agreed to in writing, software      //
// distributed under the License is distributed on an "AS IS" BASIS,        //
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
// See the License for the specific language governing permissions and      //
// limitations under the License.                                           //
// ======================================================================== //

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEngine;

public class Raytracing_Controller : MonoBehaviour
{
    public string fileName = "Raytracing.scene";
    public string prefabName = "Raytracing";
    public long photonCount = 10000000;

    public void SaveToFile()
    {
        using (var stream = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None))
        {
            var ctx = new SerializationContext(stream, FileAccess.Write);
            foreach (var node in GetComponents<Raytracing_Serializable>().Union(GetComponentsInChildren<Raytracing_Serializable>()))
            {
                node.Serialize(ctx, gameObject);
            }
        }
    }


    public GameObject CreatePrefab()
    {
        // using a temporary file since Unity is 32-bit and we could run short on memory here...
        var tmpFile = Path.GetTempFileName();

        try
        {
            using (var stream = new FileStream(tmpFile, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
            {
                var ctx = new SerializationContext(stream, FileAccess.Write);
                foreach (var node in GetComponents<Raytracing_Serializable>().Union(GetComponentsInChildren<Raytracing_Serializable>()))
                {
                    node.Serialize(ctx, gameObject);
                }

                ctx = new SerializationContext(stream, FileAccess.Read);
                var root = new GameObject("__InternalPrefabGenerator");
                try
                {
                    Raytracing_Scene.Deserialize(ctx, root);
                }
                catch (Exception)
                {
                    GameObject.DestroyImmediate(root, true);
                    throw;
                }

                return root;
            }
        }
        finally
        {
            File.Delete(tmpFile);
        }
    }
}
