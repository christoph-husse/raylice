﻿// ======================================================================== //
// Copyright 2013 Christoph Husse                                           //
//                                                                          //
// Licensed under the Apache License, Version 2.0 (the "License");          //
// you may not use this file except in compliance with the License.         //
// You may obtain a copy of the License at                                  //
//                                                                          //
//     http://www.apache.org/licenses/LICENSE-2.0                           //
//                                                                          //
// Unless required by applicable law or agreed to in writing, software      //
// distributed under the License is distributed on an "AS IS" BASIS,        //
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
// See the License for the specific language governing permissions and      //
// limitations under the License.                                           //
// ======================================================================== //

using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using UnityEditor;
using UnityEngine;
using System.Collections;

public abstract class Raytracing_Serializable : MonoBehaviour
{
    protected const int MESH_UID = 882866105;
    protected const int MATERIAL_UID = 245295346;
    protected const int GAME_OBJECT_UID = 607015836;
    protected const int SCENE_UID = 436244738;
    protected const int CAMERA_UID = 230948538;
    protected const int MESH_DATA_UID = 36788259;
    protected const int GAME_OBJECT_CHILDS_UID = 1824579230;
    protected const int DIRECTIONAL_LIGHT_UID = 1348957090;

    public abstract void Serialize(SerializationContext ctx, GameObject root);
    public abstract void Deserialize(SerializationContext ctx);

    public static void Deserialize(SerializationContext ctx, GameObject root)
    {
        while (ctx.reader.BaseStream.Position < ctx.reader.BaseStream.Length)
        {
            int magic = ctx.reader.ReadInt32();

            switch (magic)
            {
                case SCENE_UID:
                    root.AddComponent<Raytracing_Scene>().Deserialize(ctx);
                    break;
                case CAMERA_UID:
                    {
                        var obj = new GameObject();
                        obj.transform.parent = root.transform;
                        obj.AddComponent<Raytracing_Camera>().Deserialize(ctx);
                    }
                    break;
                default:
                    throw new ArgumentException("Unknown magic number. (" + magic + ", " + ctx.reader.BaseStream.Position + " < " + ctx.reader.BaseStream.Length + ")");
            }
        }
    }
}
